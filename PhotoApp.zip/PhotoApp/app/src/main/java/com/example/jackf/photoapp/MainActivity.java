package com.example.jackf.photoapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button btn_List, btn_Load, btn_Take;
    TextView tv_message;
    ImageView iv_photo;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int SELECT_A_PHOTO = 2;
    //name of file saved for camera
    String mCurrentPhotoPath;

    List<Uri> uriList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_List = findViewById(R.id.btn_List);
        btn_Load = findViewById(R.id.btn_Load);
        btn_Take = findViewById(R.id.btn_Take);
        tv_message = findViewById(R.id.tv_message);
        iv_photo = findViewById(R.id.iv_photo);

        btn_Take.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePictureIntent();
            }
        });

        btn_Load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an intent to select photo from gallery
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                //start the intent with a request code
                startActivityForResult(i, SELECT_A_PHOTO);
            }
        });

        btn_List.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent( v.getContext(), PhotoList.class);
                startActivity(i);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        //set the image in the iv_photo
        ImageView iv_photo;
        iv_photo =findViewById(R.id.iv_photo);

        //showw the file name in tv_message
        TextView tv_message;
        tv_message = findViewById(R.id.tv_message);

        uriList = ((MyApplication)this.getApplication()).getUriList();

        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK){
            Glide.with(this).load(mCurrentPhotoPath).into(iv_photo);

            tv_message.setText(mCurrentPhotoPath);

            uriList.add(Uri.fromFile(new File(mCurrentPhotoPath)));

        }
        if(requestCode == SELECT_A_PHOTO && resultCode == RESULT_OK) {
            Uri selectedPhoto = data.getData();
            Glide.with(this).load(selectedPhoto).into(iv_photo);

            tv_message.setText(selectedPhoto.toString());

            uriList.add(selectedPhoto);

        }
    }

    private void takePictureIntent(){
        Intent  takePicIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //check if there is a camera activity to handle the intent
        if(takePicIntent.resolveActivity(getPackageManager()) != null){
            //create a file to store the photo
            File photoFile = null;
            try{
                photoFile = createImageFile();
            } catch(IOException ex){
                //Error occurred when making the file
                Toast.makeText(this, "Something went wrong. Could not create file.", Toast.LENGTH_SHORT).show();
            }
            //continue only if file was made
            if(photoFile != null){
                Uri photoURI = FileProvider.getUriForFile(this, "com.example.jackf.fileprovider", photoFile);
                takePicIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePicIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    private File createImageFile() throws IOException{
        //create image file
        String timeStamp = new SimpleDateFormat("yyyyMMdd__HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName, /* prefix */
                ".jpg",  /* suffix */
                storageDir     /* directory */
        );
        //save file path for user with Intent
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }


}
